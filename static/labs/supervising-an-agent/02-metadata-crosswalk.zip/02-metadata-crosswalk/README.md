# Sample MARC Records — Metadata Crosswalk Lab

This directory contains 10 real MARC bibliographic records for use in the
"Supervising an Agent" lab on metadata crosswalking. Your job (with help from
an AI agent — Codex, Claude Cowork, Antigravity, etc.) is to read these
records, produce a Dublin Core conversion of each, and write a one-sentence
note about what got lost in translation.

## Source and attribution

These records were extracted from the
[Library Carpentry MarcEdit lesson](https://github.com/LibraryCarpentry/lc-marcedit)
sample dataset (`episodes/data/marc_sample_data.mrc`). According to that
lesson, the records originate from the **Open Textbook Library** and the
**University of Florida** library catalog. Each record carries a 588 note
indicating it is available under **Creative Commons CC0** ("No Rights
Reserved") via the University of Florida Libraries. The Library Carpentry
instructional materials are licensed CC BY 4.0.

The 10 records were selected from the larger sample to give you a variety of
material types — not just books.

## What's in the records (by leader bytes 06/07)

The records are intentionally varied so the crosswalk exercise produces
interesting edge cases. The types present:

1. **am** — book / monograph (electronic thesis)
2. **em** — cartographic material (a historical map of Africa)
3. **tm** — manuscript language material (a thesis on the Pensacola Navy Yard)
4. **jm** — musical sound recording (Chico Buarque LP)
5. **gm** — projected medium (documentary film)
6. **as** — serial (financial/operating plan, a continuing resource)
7. **gm** — projected medium (a feature film)
8. **mc** — computer file / collection
9. **ai** — integrating resource (a photograph archive)
10. **cm** — notated music (a score for chamber ensemble)

## Reading MARC if you've never seen it before

The MARC 21 standard is documented at <https://www.loc.gov/marc/bibliographic/>.
The most useful page is the "concise" version, which lists every field and
subfield in one place. Don't try to memorize it — use it as a reference
while you read.
