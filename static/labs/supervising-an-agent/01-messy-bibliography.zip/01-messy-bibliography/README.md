# Lab: Supervising an Agent — Messy Bibliography

You have inherited a partially-cleaned bibliography file (`messy-bibliography.csv`)
that a colleague compiled from various sources. It contains roughly 100 citations
on Library and Information Science topics (information literacy, public and
academic libraries, digital humanities, library instruction, reference
services), and it is a mess.

Your job: work with an AI coding agent to turn this into a clean, consistent bibliography.

You do **not** need to chase down missing data on the open web. If a year is
missing and unrecoverable from the row, marking it as missing is fine.

**Total row count:** 105 (100 originals + 5 near-duplicates).