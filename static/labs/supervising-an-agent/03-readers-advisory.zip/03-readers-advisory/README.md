# Reader's Advisory Bot

Build a small tool that helps a patron browse book award winners. These are instructions for the student, *not* the bot.

## What "small tool" can mean

You decide. Examples:

- A static HTML page that lists Newbery / Hugo / Booker / Pulitzer / NBA winners with filters by year, genre, or theme
- A chat-style interface where someone describes what they liked and the bot recommends a winner
- A tiny script that produces a printable display board for a "Featured Award Winners" library exhibit
- A reading-tracker that lets you mark which winners you've read

## Suggested data sources

You'll need to source the data yourself — part of the exercise is figuring out *how* - or figuring out how to ask a bot to do it. A few starting points:

- Wikipedia pages for each award (the agent can scrape these)
- Goodreads "Award" lists
- Library of Congress / NYPL public bibliographies
- The Pulitzer / Booker / Hugo official websites

Tell the agent which awards you want and let it figure out the rest. If it tries to make up book titles instead of looking them up — push back.

## Things to push back on

- The agent inventing books that don't exist (very common with award lists from memory)
- Missing or wrong years
- Confident summaries of books it hasn't actually read or retrieved

## Reflection focus

This task surfaces *hallucination risk*. Award lists are exactly the kind of thing a language model "remembers" approximately.
