# Data Services Librarian

**Employer:** Boston College Libraries
**Location:** Chestnut Hill, Massachusetts
**Employment Type:** Full time
**Posted:** May 12, 2026
**Salary Range:** $79,900 - $99,900
**Source:** [Code4Lib Jobs Board](https://jobs.code4lib.org/jobs/66146-data-services-librarian)
**Apply:** https://bc.csod.com/ui/internal-career-site/app/job-details/10802
**Contact:** Melanie Hubbard, melanie.hubbard@bc.edu

---

## Overview

Boston College Libraries seeks a Data Services Librarian to join its Digital
Scholarship Group. The role emphasizes collaboration within the library system
and across campus to advance data-related initiatives and services. The
position will work in partnership with a fellow Data Services Librarian to
expand existing services and create engagement opportunities around data
literacy across the university.

## Department Context

The Data Services Librarian sits within the Digital Scholarship Group at
Boston College Libraries. There is significant demand from the Economics
department and the Carroll School of Management, so comfort with economic
and business data is particularly important. The position also collaborates
with subject specialists, instructional designers, and research computing
staff.

## Key Responsibilities

- Consult on data-related research projects across the university
- Deliver training in data manipulation, management, curation, and
  documentation
- Teach courses and workshops on data skills and data literacy
- Develop educational materials and library instruction modules for data
  science programs
- Partner with a fellow Data Services Librarian to expand existing services
  and create engagement opportunities around data literacy
- Support work with diverse data types, particularly economic and business
  data
- Contribute to the broader Digital Scholarship Group's portfolio of services

## Required Qualifications

- Master's degree in Library and Information Science (MLIS) or a closely
  related, data-intensive research field
- 2-3 years of relevant experience
- Demonstrated capability in data consultation, curation, management, and
  analysis
- Experience using data technologies in academic or research settings
- Ability to work across multiple disciplines with varied audiences
  (faculty, graduate students, undergraduates, researchers)
- Strong written and verbal communication skills

## Preferred Qualifications

- Prior academic library experience
- Familiarity with complex datasets, including survey or geospatial data
- Knowledge of data platforms such as WRDS (Wharton Research Data Services)
  and FRED (Federal Reserve Economic Data)
- Experience with GIS technologies
- Experience developing training programs and teaching workshops
- Data visualization skills
- Coding proficiency in Python and/or R

## Application Instructions

Submit applications through the Boston College careers portal:
https://bc.csod.com/ui/internal-career-site/app/job-details/10802

Direct inquiries to Melanie Hubbard at melanie.hubbard@bc.edu.

Boston College is an Affirmative Action / Equal Opportunity Employer.
