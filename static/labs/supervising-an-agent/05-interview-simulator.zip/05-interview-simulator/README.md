# Interview Simulator — Example Job Posting

`job-posting.md` is an example job posting from the
[Code4Lib jobs board](https://jobs.code4lib.org), used as the basis for the
bot interviewer exercise. The agent reads this posting and role-plays
interviewing you for the position, asking workplace-specific and
role-specific questions.

You may swap this out for a posting in your own field of interest —
anywhere a real, public job description is fine. The point is to have
substantive workplace detail (department, responsibilities, required
skills, specific tools, salary band, employer context) for the agent to
interview around. Avoid postings that are just "apply via our portal"
with no description — there's nothing for the interviewer to grab onto.
